<?php
	ini_set('display_errors', 'On');
	/** Local Path to Root*/
	define('PATH', dirname(__FILE__));
	/** Includes Directory*/
	define('INC', '/inc');
	
	include_once(PATH . INC . '/config.php');
	include_once(PATH . INC . '/theme.php');
	

?>