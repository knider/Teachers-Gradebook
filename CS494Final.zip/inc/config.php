<?php
	ini_set('display_errors', 'On');
	
	/** MySQL Hostname */
	define("DB_HOST", "oniddb.cws.oregonstate.edu");
	/** MySQL Database Name */
	define("DB_NAME", "niderk-db");
	/** MySQL Server Username */
	define("DB_USER", "niderk-db");
	/** MySQL Server Password  */
	define("DB_PASS", "8qV5RXYryvcPMSf8");
	
	/** Site Home */
	define("Home", "index.php");
	/** Site Name */
	define("SiteName", "CS494 Final");
?>